#ifndef __SERVER__
#define __SERVER__
//***********************************************
#include "socket_header.h"
#include "safety_function.h"
#include "command_list.h"
//***********************************************
void RAS(int socket_fd);
//***********************************************
int main(int argc, char** argv);
//***********************************************
#endif


